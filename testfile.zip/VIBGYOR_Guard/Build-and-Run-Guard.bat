@echo off
setlocal
title VIBGYOR Guard - Build and Launch

echo ====================================
echo           VIBGYOR GUARD
echo ====================================
echo.

where dotnet >nul 2>nul
if errorlevel 1 (
  echo .NET 8 SDK was not found.
  echo Install the .NET 8 SDK from:
  echo https://dotnet.microsoft.com/download/dotnet/8.0
  echo Then run this BAT again.
  pause
  exit /b 1
)

set "ROOT=%~dp0"
set "PROJECT=%ROOT%src\VIBGYOR.Guard.csproj"
set "OUT=%ROOT%publish"

echo Building standalone Windows x64 launcher...
dotnet publish "%PROJECT%" -c Release -r win-x64 --self-contained true ^
  /p:PublishSingleFile=true /p:IncludeNativeLibrariesForSelfExtract=true ^
  -o "%OUT%"

if errorlevel 1 (
  echo.
  echo Build failed. Review the errors above.
  pause
  exit /b 1
)

echo.
echo Build complete: "%OUT%\VIBGYOR.Guard.exe"
echo.
"%OUT%\VIBGYOR.Guard.exe" %*
endlocal
