# VIBGYOR Guard (user-mode isolation launcher)

## What it does
VIBGYOR Guard starts a chosen executable using Windows `runas.exe` under a
separate, already-existing Windows account. Windows prompts for that account's
password. Guard does not save credentials.

This creates a separate Windows user profile. It is a launch helper, NOT a
sandbox, antivirus, firewall, or guaranteed containment boundary.

## Important limitations
- A separate account named `VibgyorIsolated` must already exist.
- Creating a new local Windows account may require an administrator. Guard
  cannot bypass that requirement.
- The account must be a standard (non-administrator) account.
- The folder containing VIBGYOR must be readable/executable by that account.
  A folder under your private user profile may not be accessible. If permitted,
  place a copy in `C:\Users\Public\Documents\VIBGYOR`.
- This does not stop VIBGYOR from using the internet, collecting information
  available to the isolated account, or communicating with its configured server.
- If VIBGYOR has an already-installed Windows service running as SYSTEM or
  another account, this launcher does not isolate or disable that service.
- Do not enter your everyday Windows password if the isolated account is
  supposed to have a different password.

## One-time Windows setup
Ask the PC administrator to create a local standard account:
- Username: `VibgyorIsolated`
- Account type: Standard User (not Administrator)
- Use a unique password, not your everyday account password.

The administrator should also ensure the account can sign in locally. Do not
add it to Administrators. Sign in to it once if Windows needs to initialize
its profile, then sign out.

If the account already exists, no administrator setup is needed.

## Build
Requirements: Windows 10/11 and .NET 8 SDK.
1. Extract this folder.
2. Double-click `Build-and-Run-Guard.bat`.
3. The BAT publishes `publish\VIBGYOR.Guard.exe` as a self-contained x64 app
   and launches it.
4. Enter the full path to `VIBGYOR.exe`, or drag the file into the console.
5. Confirm. Windows will prompt for the isolated account password.

After the first build, use `Run-Guard.bat` or `publish\VIBGYOR.Guard.exe`.

## Optional command line
`VIBGYOR.Guard.exe "C:\Users\Public\Documents\VIBGYOR\VIBGYOR.exe" .\VibgyorIsolated`

## What to verify
After launching, open Task Manager and check the VIBGYOR process's user name.
It should show `VibgyorIsolated`, not your everyday account. Also verify that
the isolated account cannot browse your private user folders. Do not assume
isolation succeeded merely because the launcher printed a success message.

## Source
The C# source is in `src\Program.cs`. Review it before building. It only invokes
Windows `runas.exe`; it does not install a service, create persistence, alter
ACLs, or disable security controls.
