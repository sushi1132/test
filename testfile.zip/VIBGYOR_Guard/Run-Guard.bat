@echo off
setlocal
set "GUARD=%~dp0publish\VIBGYOR.Guard.exe"
if not exist "%GUARD%" (
  echo Guard EXE not found. Run Build-and-Run-Guard.bat first.
  pause
  exit /b 1
)
"%GUARD%" %*
endlocal
