using System.Diagnostics;
using System.Security.Principal;

static class Program
{
    private const string DefaultAccount = @".\VibgyorIsolated";

    static int Main(string[] args)
    {
        Console.Title = "VIBGYOR Guard";
        Console.WriteLine("====================================");
        Console.WriteLine("          VIBGYOR GUARD");
        Console.WriteLine("     Separate-account launcher");
        Console.WriteLine("====================================");
        Console.WriteLine();
        Console.WriteLine("This launcher starts the selected program under a DIFFERENT");
        Console.WriteLine("Windows account. It does not modify VIBGYOR or block its network.");
        Console.WriteLine();

        string currentUser = WindowsIdentity.GetCurrent().Name;
        Console.WriteLine($"Current account: {currentUser}");
        Console.WriteLine();

        string exePath = args.Length > 0 ? Path.GetFullPath(args[0]) : AskForExe();
        if (string.IsNullOrWhiteSpace(exePath) || !File.Exists(exePath))
        {
            Console.WriteLine("ERROR: The executable was not found.");
            Pause();
            return 2;
        }

        string account = args.Length > 1 ? args[1] : DefaultAccount;
        if (string.Equals(NormalizeAccount(account), NormalizeAccount(currentUser),
                StringComparison.OrdinalIgnoreCase))
        {
            Console.WriteLine("ERROR: The isolation account cannot be your current account.");
            Pause();
            return 3;
        }

        Console.WriteLine($"Program: {exePath}");
        Console.WriteLine($"Run as:  {account}");
        Console.WriteLine();
        Console.WriteLine("Windows will request the isolated account password.");
        Console.WriteLine("The password is handled by Windows and is not saved by Guard.");
        Console.WriteLine();
        Console.Write("Continue? [Y/N]: ");
        string? answer = Console.ReadLine();
        if (!string.Equals(answer?.Trim(), "Y", StringComparison.OrdinalIgnoreCase))
        {
            Console.WriteLine("Cancelled.");
            return 0;
        }

        // runas.exe uses Windows' own credential prompt and does not store the password.
        // The target account must already exist and be permitted to sign in locally.
        var psi = new ProcessStartInfo
        {
            FileName = "runas.exe",
            Arguments = $"/profile /user:{QuoteAccount(account)} \"{exePath}\"",
            UseShellExecute = false,
            CreateNoWindow = false
        };

        try
        {
            using Process? process = Process.Start(psi);
            if (process == null)
            {
                Console.WriteLine("ERROR: Windows could not start runas.exe.");
                Pause();
                return 4;
            }

            process.WaitForExit();
            if (process.ExitCode != 0)
            {
                Console.WriteLine();
                Console.WriteLine($"Windows runas returned exit code {process.ExitCode}.");
                Console.WriteLine("Check that the account exists, its password is correct,");
                Console.WriteLine("and the program folder is readable by that account.");
            }
            else
            {
                Console.WriteLine();
                Console.WriteLine("Windows accepted the launch request.");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"ERROR: {ex.Message}");
            Pause();
            return 5;
        }

        Pause();
        return 0;
    }

    private static string AskForExe()
    {
        Console.Write("Full path to VIBGYOR.exe (or drag the file here): ");
        string? input = Console.ReadLine()?.Trim().Trim('"');
        return string.IsNullOrWhiteSpace(input) ? "" : Path.GetFullPath(Environment.ExpandEnvironmentVariables(input));
    }

    private static string NormalizeAccount(string value) =>
        value.Replace("/", @"\").Trim().TrimStart('.','\\');

    private static string QuoteAccount(string value) =>
        value.Contains(' ') ? $"\"{value}\"" : value;

    private static void Pause()
    {
        Console.WriteLine();
        Console.Write("Press Enter to close...");
        Console.ReadLine();
    }
}
